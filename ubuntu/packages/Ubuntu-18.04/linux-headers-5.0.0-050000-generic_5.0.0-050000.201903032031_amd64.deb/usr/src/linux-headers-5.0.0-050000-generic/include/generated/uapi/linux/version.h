#define LINUX_VERSION_CODE 327680
#define KERNEL_VERSION(a,b,c) (((a) << 16) + ((b) << 8) + (c))
