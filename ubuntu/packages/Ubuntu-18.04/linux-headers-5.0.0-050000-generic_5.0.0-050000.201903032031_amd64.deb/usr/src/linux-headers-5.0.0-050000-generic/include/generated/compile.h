/* This file is auto generated, version 201903032031 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201903032031 SMP Fri Jan 24 13:59:54 CET 2020"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "mediacenter"
#define LINUX_COMPILER "gcc version 7.4.0 (Ubuntu 7.4.0-1ubuntu1~18.04.1)"
